# Description

The xADUser DSC resource will manage Users within Active Directory.
